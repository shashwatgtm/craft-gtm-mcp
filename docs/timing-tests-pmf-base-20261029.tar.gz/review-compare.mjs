import { createHash } from 'node:crypto';
import { writeFileSync, mkdirSync } from 'node:fs';
import assert from 'node:assert/strict';
import oldHandler from '/workspace/work/w5c-resume/overlays/craft-gtm-mcp/netlify/functions/mcp.mjs';
import newHandler from './overlay/netlify/functions/mcp.mjs';
const plan = 'Synthetic Northwind planning exercise. Target: revenue operations directors at firms with 200 to 1000 employees. Outcome: 20 discovery meetings. Owner: marketing director. Timeline: 1 January to 31 March 2027. Budget: USD 15000. Channels: customer webinars and partner referrals. Review progress weekly.';
const pmf = current_metrics => ({ product: 'Northwind CRM, synthetic review scenario only', target_market: 'smb_saas', current_metrics, business_model: 'saas' });
const cases = [
 ['pmf-missing-dimension','pmf_scorecard',pmf('Synthetic figures only: monthly churn 3%; NPS 45; CAC $500; LTV $3000; retention 92%')],
 ['pmf-complete','pmf_scorecard',pmf('Synthetic figures only: monthly churn 2%; NPS 65; CAC $500; LTV $3000; retention 95%; activation 75%')],
 ['discovery','customer_interview_kit',{ interview_type: 'discovery', product_context: 'Synthetic research exercise about Northwind CRM administration', target_persona: 'Revenue operations director', key_hypotheses: 'Manual data entry delays pipeline reporting.' }],
 ['labeled-plan','craft_gtm_analyzer',{ document_content: plan, document_type: 'quarterly_plan', intended_audience: 'CMO' }],
 ['numeric-target','craft_gtm_analyzer',{ document_content: 'Owner: sales director.\nTarget: 40 qualified meetings by 31 March 2027.', document_type: 'quarterly_plan' }],
];
async function call(handler,name,args) {
 const r=await handler(new Request('https://x.gtmhelix.com/mcp',{method:'POST',headers:{'content-type':'application/json',accept:'application/json, text/event-stream'},body:JSON.stringify({jsonrpc:'2.0',id:1,method:'tools/call',params:{name,arguments:args}})}));
 const b=await r.json();return b.result.content.map(c=>c.text).join('\n');
}
const sha=s=>createHash('sha256').update(s).digest('hex');
mkdirSync(new URL('./review-outputs',import.meta.url),{recursive:true});
const results=[];
for(const [label,name,args] of cases){
 const a=await call(oldHandler,name,args),b=await call(newHandler,name,args);
 writeFileSync(new URL(`./review-outputs/${label}-prior.txt`,import.meta.url),a);
 writeFileSync(new URL(`./review-outputs/${label}-current.txt`,import.meta.url),b);
 if(label==='labeled-plan')assert.match(b,/39\s*\/\s*50/);
 results.push({label,tool:name,prior_sha256:sha(a),current_sha256:sha(b),equal:a===b});
}
writeFileSync(new URL('./review-comparison.json',import.meta.url),JSON.stringify(results,null,2));
console.log(JSON.stringify(results,null,2));
console.log('Current labeled analyzer fixture remains 39/50: PASS');
