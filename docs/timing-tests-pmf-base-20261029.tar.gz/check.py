from pathlib import Path
import subprocess,json,os,time,hashlib
w=Path('/workspace/work/w5c-pmf');root=w/'overlay';logs=w/'logs';logs.mkdir(exist_ok=True);receipts=[]
node=['node','--test','--test-isolation=none','--test-reporter=tap']
def run(label,args,cwd=root):
 log=logs/(label+'.log');start=time.monotonic()
 with log.open('w') as out:
  try:rc=subprocess.run(args,cwd=cwd,stdout=out,stderr=subprocess.STDOUT,timeout=120).returncode
  except subprocess.TimeoutExpired:rc=124;out.write('\nHARNESS TIMEOUT 120 seconds\n')
 receipts.append(dict(label=label,argv=args,cwd=str(cwd),exit=rc,seconds=round(time.monotonic()-start,3),log=log.name,sha256=hashlib.sha256(log.read_bytes()).hexdigest()));(w/'receipts.json').write_text(json.dumps(receipts,indent=2));print(label,rc,flush=True)
run('build',['npm','run','build'])
files=sorted(str(p.relative_to(root)) for p in (root/'tests').glob('*.test.mjs'))
run('full-suite',node+files)
run('five-saved-host-fixtures',['node','review-compare.mjs'],w)
loads=[];cpu=min(os.sched_getaffinity(0))
try:
 for _ in range(2):loads.append(subprocess.Popen(['taskset','-c',str(cpu),'python','-c','import time\nend=time.monotonic()+120\nx=1\nwhile time.monotonic()<end:x=(x*1664525+1013904223)%4294967296'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL))
 for label,files in [('busy-timing',['tests/run40s-escape.test.mjs']),('busy-host-review',['tests/host-review-20261029.test.mjs'])]:run(label,['taskset','-c',str(cpu)]+node+files)
finally:
 for p in loads:p.terminate()
 for p in loads:p.wait()
 (w/'load.json').write_text(json.dumps(dict(cpu=cpu,workers=2,maximum_seconds=120,stopped=[p.poll() is not None for p in loads]),indent=2))
