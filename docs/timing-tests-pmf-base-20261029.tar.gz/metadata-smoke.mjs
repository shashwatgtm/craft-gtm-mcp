import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import handler from './overlay/netlify/functions/mcp.mjs';
import oldHandler from '/workspace/work/w5c-resume/overlays/craft-gtm-mcp/netlify/functions/mcp.mjs';
const list=async fn=>{
 const r=await fn(new Request('https://x.gtmhelix.com/mcp',{method:'POST',headers:{'content-type':'application/json',accept:'application/json, text/event-stream'},body:JSON.stringify({jsonrpc:'2.0',id:1,method:'tools/list',params:{}})}));
 return (await r.json()).result.tools.map(t=>t.name).sort();
};
const current=await list(handler),prior=await list(oldHandler);
assert.equal(current.length,8);assert.deepEqual(current,prior);
assert.equal(JSON.parse(readFileSync(new URL('./overlay/package.json',import.meta.url))).version,'2.2.23');
console.log('Version 2.2.23, eight tool names unchanged: PASS');
