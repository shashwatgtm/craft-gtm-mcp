from pathlib import Path
import shutil,json,hashlib
w=Path('/workspace/work/w5c-pmf');old=Path('/workspace/work/w5c-resume/overlays/craft-gtm-mcp');new=w/'overlay'
shutil.copytree(old,new,ignore=shutil.ignore_patterns('node_modules'))
(new/'node_modules').symlink_to(Path('/workspace/craft-gtm-mcp/node_modules'),target_is_directory=True)
for f in json.loads((w/'remote-files.json').read_text()):
 b=f['content'].encode();assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==f['sha'];(new/f['path']).write_bytes(b)
m=json.loads((w/'metadata.json').read_text());patch={x['path']:x['sha'] for x in m['patchFiles']}
for f in m['sourceFiles']+m['patchFiles']:
 p=new/f['path'];b=p.read_bytes();actual=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
 assert actual==patch.get(f['path'],f['sha']),f['path']
print('Exact source and patch blobs verified. No video fetched or changed.')
