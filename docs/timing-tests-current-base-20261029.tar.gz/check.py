from pathlib import Path
import subprocess,json,time,os,hashlib
W=Path('/workspace/work/w5c-resume');records=[];(W/'logs').mkdir(exist_ok=True)
repos=['craft-gtm-mcp','craft-content-mcp'];node=['node','--test','--test-isolation=none','--test-reporter=tap']
def run(repo,label,cmd,affinity=None):
 root=W/'overlays'/repo;args=(['taskset','-c',str(affinity)] if affinity is not None else [])+cmd;log=W/'logs'/f'{repo}-{label}.log';start=time.monotonic()
 with log.open('w') as out:
  try:rc=subprocess.run(args,cwd=root,stdout=out,stderr=subprocess.STDOUT,timeout=120).returncode
  except subprocess.TimeoutExpired:rc=124;out.write('\nHARNESS TIMEOUT: 120 seconds\n')
 records.append(dict(repo=repo,label=label,cwd=str(root),argv=args,exit=rc,seconds=round(time.monotonic()-start,3),log=log.name,log_sha256=hashlib.sha256(log.read_bytes()).hexdigest()));(W/'receipts.json').write_text(json.dumps(records,indent=2));print(repo,label,rc,flush=True)
for repo in repos:
 run(repo,'build',['npm','run','build'])
 files=sorted(str(p.relative_to(W/'overlays'/repo)) for p in (W/'overlays'/repo/'tests').glob('*.test.mjs'))
 run(repo,'suite',node+files)
# Direct review fixture check for the requested analyzer score.
repo='craft-gtm-mcp';script=W/'overlays'/repo/'w5c-score.mjs'
script.write_text('''import assert from 'node:assert/strict';
import handler from './netlify/functions/mcp.mjs';
const plan = "Synthetic Northwind planning exercise. Target: revenue operations directors at firms with 200 to 1000 employees. Outcome: 20 discovery meetings. Owner: marketing director. Timeline: 1 January to 31 March 2027. Budget: USD 15000. Channels: customer webinars and partner referrals. Review progress weekly.";
const r=await handler(new Request('https://x.gtmhelix.com/mcp',{method:'POST',headers:{'content-type':'application/json',accept:'application/json, text/event-stream'},body:JSON.stringify({jsonrpc:'2.0',id:1,method:'tools/call',params:{name:'craft_gtm_analyzer',arguments:{document_content:plan,document_type:'quarterly_plan',intended_audience:'CMO'}}})}));
const body=await r.json(); const text=body.result.content.map(c=>c.text).join('\\n');
assert.match(text,/39\\s*\\/\\s*50/); console.log('Synthetic labeled review fixture analyzer score 39/50: PASS');
''')
run(repo,'review-score',['node','w5c-score.mjs'])
cpu=min(os.sched_getaffinity(0));loads=[]
try:
 for i in range(2):loads.append(subprocess.Popen(['taskset','-c',str(cpu),'python','-c','import time\nend=time.monotonic()+120\nx=1\nwhile time.monotonic()<end: x=(x*1664525+1013904223)%4294967296'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL))
 for repo in repos:
  f='tests/run40s-escape.test.mjs' if repo=='craft-gtm-mcp' else 'tests/run22-echo-gaps.test.mjs'
  run(repo,'busy-targeted',node+[f],cpu)
  hosts=sorted(str(p.relative_to(W/'overlays'/repo)) for p in (W/'overlays'/repo/'tests').glob('host-review-*.test.mjs'))
  run(repo,'busy-host-review',node+hosts,cpu)
finally:
 for p in loads:p.terminate()
 for p in loads:p.wait()
 (W/'load.json').write_text(json.dumps(dict(cpu=cpu,workers=2,maximum_seconds=120,stopped=[p.poll() is not None for p in loads]),indent=2))
