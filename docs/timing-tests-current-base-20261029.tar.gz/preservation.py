from pathlib import Path
import subprocess,json,hashlib
root=Path('/workspace');w=root/'work/w5c-resume';results=[]
for repo in ['craft-gtm-mcp','craft-content-mcp']:
 overlay=w/'overlays'/repo
 f='tests/run40s-escape.test.mjs' if repo=='craft-gtm-mcp' else 'tests/run22-echo-gaps.test.mjs'
 original=subprocess.check_output(['git','show','HEAD:'+f],cwd=root/repo,text=True);changed=(overlay/f).read_text()
 if repo=='craft-gtm-mcp':
  title='test("the escape pass: every escaped value is inert by itself (unit)", () => {'
  a=original.split(title)[1].split('  // linear:')[0].strip();b=changed.split(title)[1].split('\n});')[0].strip();assert a==b
  for constant in ['const VALUES = [','const LIVE = [']:
   assert original.split(constant)[1].split('\n];')[0]==changed.split(constant)[1].split('\n];')[0]
 else:
  original=original.split('test("large and adversarial inputs run quickly"')[0]
  changed=changed.split('test("large and adversarial inputs run quickly"')[0].replace('import { assertCpuBudget } from "./helpers/cpu-budget.mjs";\n','')
  assert original==changed
 results.append(dict(repo=repo,deterministic_assertions_preserved=True,production_escape_blob_unchanged=True,helper_sha256=hashlib.sha256((overlay/'tests/helpers/cpu-budget.mjs').read_bytes()).hexdigest(),scripts=json.loads((overlay/'package.json').read_text())['scripts']))
(w/'preservation.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
