import assert from 'node:assert/strict';
import handler from './netlify/functions/mcp.mjs';
const plan = "Synthetic Northwind planning exercise. Target: revenue operations directors at firms with 200 to 1000 employees. Outcome: 20 discovery meetings. Owner: marketing director. Timeline: 1 January to 31 March 2027. Budget: USD 15000. Channels: customer webinars and partner referrals. Review progress weekly.";
const r=await handler(new Request('https://x.gtmhelix.com/mcp',{method:'POST',headers:{'content-type':'application/json',accept:'application/json, text/event-stream'},body:JSON.stringify({jsonrpc:'2.0',id:1,method:'tools/call',params:{name:'craft_gtm_analyzer',arguments:{document_content:plan,document_type:'quarterly_plan',intended_audience:'CMO'}}})}));
const body=await r.json(); const text=body.result.content.map(c=>c.text).join('\n');
assert.match(text,/39\s*\/\s*50/); console.log('Synthetic labeled review fixture analyzer score 39/50: PASS');
